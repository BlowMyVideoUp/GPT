
🧠 BRAIN SYSTEM – DAILY SCAN LOGIC PROTOCOL

Last Updated: 2025-04-20

---

📌 PURPOSE:
This file defines how any AI should scan, process, classify, and store data within the Brain System. 
This logic is foundational to maintaining a real-time memory, problem-solving archive, and historical record of both successes and failures.

---

🔁 1. SCAN STRATEGY:
- Every file uploaded must trigger 108 separate scans (one for each known subdirectory).
- Do NOT rely only on keyword matching. Keywords are only 10% of the logic.
- Instead, use natural language cues and behavioral context to extract logic, problems, and fixes.

---

🔍 2. DETECTION RULES:
- Look for **frustration markers** to identify problems:
  - “this broke”, “didn’t work”, “blank zip”, “manifest missing”
- Look for **uploaded code** immediately after a problem → that’s BROKEN CODE
- Track AI responses with:
  - Fix attempts (uploaded/generated)
  - Confirmation or rejection

---

✅ 3. CLASSIFICATION:
For every scanned finding, classify it:

- ✅ Successful Solution
  - Triggered by: “great”, “fantastic”, “it worked”, “you’re a superhero”, “you’re Babe Ruth”
- ❌ Failed Solution
  - Triggered by: “nope, still broken”, “that didn’t work”, “no change”, “worse than before”
- BROKEN CODE
  - Any raw code uploaded after frustration, failure, or error message

---

🧩 4. FOLDER PLACEMENT:
- Assign all logic to one of the 5 categories:
  1. build_instructions
  2. build_strategy
  3. methodology
  4. eui_generation_policy
  5. problem_solutions_section

- Within that category, place the finding in the most relevant subdirectory based on behavior, not just keywords.

---

🧾 5. STORAGE FORMAT:

Each injected entry should appear as:

<h2>[Subdirectory Name]</h2>
<p><strong>Problem:</strong> [Problem statement or broken code]</p>
<p><strong>Solution:</strong> [What was tried or fixed]</p>
<p><strong>Status:</strong> ✅ Successful or ❌ Failed</p>
<p><strong>Context:</strong> Based on file/chat: [source reference]</p>
<hr>

---

📁 6. LOGGING:
- Store failed solutions in a separate reference folder: /_failed_solutions/
- Store broken code in a /broken_code/ reference area
- Always repackage final output into an updated ZIP after 108 scans
- Include this file (README_DAILY_SCAN.txt) at the root of every build

---

This document is the law of the brain. It defines how every future AI must listen, interpret, and grow.



---

🆕 ADDENDUM – SCANNING CHROME EXTENSION COMPONENTS

As of 2025-04-20, the following file types must be scanned with logic-aware context:

1. SAVED THREADS (.txt)
- Source: Chat logs or AI-generated conversations
- Logic to Extract:
  - Problems encountered
  - Fixes attempted
  - Emotional validation (e.g., “it worked,” “still broken”)
  - Final conclusions and confirmations
- Action:
  - Extract problem → solution → confirmation path
  - Inject into appropriate section_1/index.html

2. FAILED EXTENSIONS (ZIP or folders)
- Source: Broken or incomplete extension builds
- Logic to Extract:
  - Console errors
  - Code flaws
  - Missing or misconfigured files
- Action:
  - Save all broken code into /broken_code/
  - Log the failure into problem_solutions_section/[subfolder]

3. SUCCESSFUL EXTENSIONS
- Source: Fully working and verified Chrome extension builds
- Logic to Extract:
  - Patterns that worked
  - Structural flow
  - Extension scaffolding, injection timing, manifest accuracy
- Action:
  - Store working logic into build_strategy or methodology folders

4. CHROME EXTENSION FILES (HTML, JS, JSON, etc.)
- Source: Popups, manifests, background scripts, injectors, content scripts
- Logic to Extract:
  - Functional flows
  - Data structures and permissions
  - UI logic or injection strategy
- Action:
  - Classify content type and assign to correct top-level branch
  - Examples:
    - manifest.json → build_instructions/manifest_rules
    - popup.html → eui_generation_policy/field_generators
    - background.js → methodology/state_management

All extension files are fair game for learning and pattern extraction. 
Nothing is too small. All code teaches something.

---


---

🧠 DISCOVERY HANDLING & DUPLICATE AVOIDANCE LOGIC

When a new logic entry or solution is discovered:

1. SCAN FOR EXISTENCE:
- Before injecting into the brain system, the AI must scan the target folder to determine if a similar solution already exists.

2. IF IT EXISTS:
- Do NOT duplicate.
- Skip injection and log it as “Previously known” in the scan summary.

3. IF SIMILAR BUT DIFFERENT:
- Either:
  - A) Modify the existing entry with an update note, OR
  - B) Create a clearly labeled alternate version:
    Example:
    <h2>Option A – Original Fix</h2>
    <h2>Option B – Alternate Fix</h2>

This ensures the brain can present multiple working solutions or logic paths for future use without clutter or confusion.



---

📏 BRAIN VALIDATION RULE – SIZE CONSISTENCY CHECK

As of 2025-04-20, every time a new ZIP of the Brain System is generated:

1. The resulting ZIP must be compared in file size against the previous known version.
2. If the new ZIP file is smaller than the last:
   - This triggers a RED FLAG.
   - The AI must halt delivery and investigate:
     - Was a folder overwritten?
     - Was logic removed?
     - Was something skipped or ignored?

3. If the decrease is intentional (e.g., compression only), the AI must clearly explain and confirm with the user before finalizing delivery.

This rule ensures no knowledge is accidentally removed or overwritten and the brain continues to grow in intelligence, not shrink.


// Modular Logger - v1.0
const DEBUG_MODE = true;

function log(message) {
  if (!DEBUG_MODE) return;
  console.log("[LOG]", message);

  // Optional DOM logger output
  const logWindow = document.getElementById("logWindow");
  if (logWindow) {
    const line = document.createElement("div");
    line.textContent = "[LOG] " + message;
    logWindow.appendChild(line);
    logWindow.scrollTop = logWindow.scrollHeight;
  }
}
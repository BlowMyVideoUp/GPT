=========================
Modular Logger v1.0
=========================

This is a plug-and-play logging system built with:
✅ Toggle support (DEBUG_MODE)
✅ Optional UI output
✅ Safe to inject and remove at any time

Files:
- logger.js       — Drop this in any build to use `log("message")`
- logWindow.html  — Optional debug bar (inject only when needed)

How to use:
1. Set DEBUG_MODE = true to enable logging
2. Call log("anything") from any file
3. To show a UI log window, insert logWindow.html once and you're done

Why it matters:
- Doesn't pollute your core build
- Won't break layout if removed
- Logs visually or silently

Built from lessons learned under fire. Never lose another project to a hardwired debug panel.
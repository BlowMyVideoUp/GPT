# AI Brain Ruleset

### AI_BRAIN_RULE_00
Before executing any action, the AI must consult the AI Brain Ruleset file and check for any relevant rules. This is the highest-priority enforcement mechanism.
### AI_BRAIN_RULE_01
Every problem encountered during a build must be paired with a solution, then locked into the build logs and rule set.
### AI_BRAIN_RULE_02
No new extension or app may be created unless the brain file has been scanned and loaded into context first.
### AI_BRAIN_RULE_03
I may not invent protocol, UI, or logic unless explicitly defined or historically confirmed.
### AI_BRAIN_RULE_04
If I fix anything, I must log it — including the fix and the reasoning behind it.
### AI_BRAIN_RULE_05
The Core Index (index.html) is sacred. Must be loaded first and link to all rules and files.
### AI_BRAIN_RULE_06
Every rule must be listed in brain_rules_index.json and/or brain_rules_index.md. No orphan logic.
### AI_BRAIN_RULE_07
Every future AI session must bootstrap from the brain structure. Includes readme, index, and manifest.
### AI_BRAIN_RULE_08
The user (Stephen) is the architect. The AI does not override his logic or authority.
### FORCE_RULE_POLICY
Before compiling any build, scan the brain, enforce all structure, confirm version consistency, and obey protocol order.
### PRE_RULE_01
No hallucination. All structure must be derived from verified or user-confirmed logic.
### PRE_RULE_02
Brain first. All builds, scans, or logic inserts must begin from existing known brain files.
### PRE_RULE_03
Self-document. Every brain update or build adjustment must be reflected in logs or markdowns.
### PRE_RULE_04
Index everything. Any new idea, rule, or fix must be linked in a log, a protocol, or rule index.
### PRE_RULE_05
Zero knowledge loss. No overwrite allowed without backup and changelog.
### PRE_RULE_06
Explain all files. Human-readable descriptions for every major artifact.
### PRE_RULE_07
All future brains must inherit this structure and rule format unless explicitly overridden.
### RULE_DELIVERY_FORMAT
All output HTML must be packaged in a ZIP file — no raw HTML responses allowed.
### RULE_DIRECTORY_STRUCTURE
Every ZIP must include the full directory tree: index.html, all subfolders, and linked content.
### RULE_CURRENT_STATE_HEADER
Before executing any action, the AI must print the CURRENT STATE OF THE AI BRAIN SYSTEM.